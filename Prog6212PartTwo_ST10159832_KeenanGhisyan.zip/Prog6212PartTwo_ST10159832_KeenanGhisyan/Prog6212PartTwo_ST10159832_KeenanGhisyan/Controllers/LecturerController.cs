﻿using Microsoft.AspNetCore.Mvc;
using Prog6212PartTwo_ST10159832_KeenanGhisyan.Models;

namespace Prog6212PartTwo_ST10159832_KeenanGhisyan.Controllers
{
    public class LecturerController : Controller
    {

        // Static list to store lecturer details
        public static List<LecturerViewModel> LecturerList = new List<LecturerViewModel>();

        // Static list to store claims
        public static List<ClaimViewModel> ClaimsList = new List<ClaimViewModel>();

        public IActionResult LecturerDetails()
        {
            return View();
        }

       

    }
}

