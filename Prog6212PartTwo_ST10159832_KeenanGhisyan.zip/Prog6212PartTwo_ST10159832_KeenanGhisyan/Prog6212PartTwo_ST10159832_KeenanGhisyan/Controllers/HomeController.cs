using Microsoft.AspNetCore.Mvc;
using Prog6212PartTwo_ST10159832_KeenanGhisyan.Models;
using System.Diagnostics;

namespace Prog6212PartTwo_ST10159832_KeenanGhisyan.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            var requestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier;
            _logger.LogError($"An error occurred with Request ID: {requestId}");

            var errorViewModel = new ErrorViewModel { RequestId = requestId };
            return View(errorViewModel);
        }
    }
}
