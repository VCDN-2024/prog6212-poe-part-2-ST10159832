﻿using Microsoft.AspNetCore.Mvc;
using Prog6212PartTwo_ST10159832_KeenanGhisyan.Models;

namespace Prog6212PartTwo_ST10159832_KeenanGhisyan.Controllers
{
    public class AcademicManagerController : Controller
    {
        // GET: AcademicManagerDetails
        public ActionResult AcademicManagerDetails()
        {
            return View();
        }

        // POST: AcademicManagerDetails
        [HttpPost]
        public ActionResult AcademicManagerDetails(AcademicManagerClaimsViewModel model)
        {
            if (!string.IsNullOrEmpty(model.UserId) && model.UserId.StartsWith("0"))
            {
                if (model.Password == "admin")
                {
                    // Both ID and password are valid, redirect to processed claims page
                    return RedirectToAction("ManageProcessedClaims", "AcademicManager");
                }
                else
                {
                    // Password is invalid, show error and ask user to try again
                    ModelState.AddModelError("Password", "The password is incorrect. Please try again.");
                }
            }
            else
            {
                // ID is invalid, clear the UserId field and show error message
                model.UserId = string.Empty; // Clear UserId field
                ModelState.AddModelError("UserId", "Invalid User ID. Please try again.");
            }

            // Return the view with the model and error messages
            return View(model);
        }

        // GET: Display claims processed by the Programme Coordinator and pending Academic Manager approval
        public ActionResult ManageProcessedClaims()
        {
            // Retrieve claims that are pending Academic Manager approval
            var processedClaims = LecturerController.ClaimsList
                .Where(c => c.ClaimStatus == "Pending Academic Manager Approval" ||
                            c.ClaimStatus == "Declined by Coordinator").ToList();

            var viewModel = new AcademicManagerClaimsViewModel
            {
                ProcessedClaims = processedClaims
            };

            return View(viewModel);
        }

        // GET: Review claim details before approval/decline
        public ActionResult ReviewClaim(int claimId)
        {
            // Fetch claim details by claimId
            var claim = LecturerController.ClaimsList.FirstOrDefault(c => c.ClaimId == claimId);

            if (claim == null)
            {
                return NotFound();
            }

            return View(claim);
        }

        // POST: Approve or Decline the claim
        [HttpPost]
        public ActionResult ProcessClaim(int claimId, string actionType)
        {
            // Fetch claim by claimId
            var claim = LecturerController.ClaimsList.FirstOrDefault(c => c.ClaimId == claimId);
            if (claim == null)
            {
                return NotFound();
            }

            // Process the claim based on the actionType
            if (actionType == "approve")
            {
                claim.ClaimStatus = "Approved by Academic Manager";
            }
            else if (actionType == "decline")
            {
                claim.ClaimStatus = "Declined by Academic Manager";
            }

            return RedirectToAction("ManageProcessedClaims");
        }


    }

}
