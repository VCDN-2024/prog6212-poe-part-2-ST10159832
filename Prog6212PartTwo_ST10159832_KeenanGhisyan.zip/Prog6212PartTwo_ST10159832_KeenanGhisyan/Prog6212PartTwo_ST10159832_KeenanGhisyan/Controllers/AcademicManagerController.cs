﻿using Microsoft.AspNetCore.Mvc;
using Prog6212PartTwo_ST10159832_KeenanGhisyan.Models;

namespace Prog6212PartTwo_ST10159832_KeenanGhisyan.Controllers
{
    public class AcademicManagerController : Controller
    {
        // GET: AcademicManagerDetails
        public ActionResult AcademicManagerDetails()
        {
            return View();
        }

      
    }
}
