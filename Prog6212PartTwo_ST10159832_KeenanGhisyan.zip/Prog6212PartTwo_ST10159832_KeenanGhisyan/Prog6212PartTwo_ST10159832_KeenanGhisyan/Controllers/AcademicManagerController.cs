﻿using Microsoft.AspNetCore.Mvc;
using Prog6212PartTwo_ST10159832_KeenanGhisyan.Models;

namespace Prog6212PartTwo_ST10159832_KeenanGhisyan.Controllers
{
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.Extensions.Logging; // Add this using directive
    using System;
    using System.Linq;

    public class AcademicManagerController : Controller
    {
        private readonly ILogger<AcademicManagerController> _logger; // Declare the logger

        // Inject the logger through the constructor
        public AcademicManagerController(ILogger<AcademicManagerController> logger)
        {
            _logger = logger; // Initialize the logger
        }

        // GET: AcademicManagerDetails
        public ActionResult AcademicManagerDetails()
        {
            return View();
        }

        // POST: AcademicManagerDetails
        [HttpPost]
        public ActionResult AcademicManagerDetails(AcademicManagerClaimsViewModel model)
        {
            try
            {
                if (!string.IsNullOrEmpty(model.UserId) && model.UserId.StartsWith("0"))
                {
                    if (model.Password == "admin")
                    {
                        // Both ID and password are valid, redirect to processed claims page
                        return RedirectToAction("ManageProcessedClaims", "AcademicManager");
                    }
                    else
                    {
                        // Password is invalid, show error and ask user to try again
                        ModelState.AddModelError("Password", "The password is incorrect. Please try again.");
                    }
                }
                else
                {
                    // ID is invalid, clear the UserId field and show error message
                    model.UserId = string.Empty; // Clear UserId field
                    ModelState.AddModelError("UserId", "Invalid User ID. Please try again.");
                }

                // Return the view with the model and error messages
                return View(model);
            }
            catch (Exception ex)
            {
                // Log the exception
                _logger.LogError(ex, "An error occurred while processing the Academic Manager details.");
                ModelState.AddModelError("", "An unexpected error occurred. Please try again later.");
                return View(model);
            }
        }

        // GET: Display claims processed by the Programme Coordinator and pending Academic Manager approval
        public ActionResult ManageProcessedClaims()
        {
            try
            {
                // Retrieve claims that are pending Academic Manager approval
                var processedClaims = LecturerController.ClaimsList
                    .Where(c => c.ClaimStatus == "Pending Academic Manager Approval" ||
                                c.ClaimStatus == "Declined by Coordinator").ToList();

                var viewModel = new AcademicManagerClaimsViewModel
                {
                    ProcessedClaims = processedClaims
                };

                return View(viewModel);
            }
            catch (Exception ex)
            {
                // Log the exception
                _logger.LogError(ex, "An error occurred while retrieving processed claims.");
                ModelState.AddModelError("", "An unexpected error occurred while fetching claims. Please try again later.");
                return View(new AcademicManagerClaimsViewModel()); // Return an empty model or handle as needed
            }
        }

        // GET: Review claim details before approval/decline
        public ActionResult ReviewClaim(int claimId)
        {
            try
            {
                // Fetch claim details by claimId
                var claim = LecturerController.ClaimsList.FirstOrDefault(c => c.ClaimId == claimId);

                if (claim == null)
                {
                    return NotFound();
                }

                return View(claim);
            }
            catch (Exception ex)
            {
                // Log the exception
                _logger.LogError(ex, $"An error occurred while reviewing the claim with ID {claimId}.");
                return NotFound(); // Optionally, you can handle the error more gracefully if needed
            }
        }

        // POST: Approve or Decline the claim
        [HttpPost]
        public ActionResult ProcessClaim(int claimId, string actionType)
        {
            try
            {
                // Fetch claim by claimId
                var claim = LecturerController.ClaimsList.FirstOrDefault(c => c.ClaimId == claimId);
                if (claim == null)
                {
                    return NotFound();
                }

                // Process the claim based on the actionType
                if (actionType == "approve")
                {
                    claim.ClaimStatus = "Approved by Academic Manager";
                }
                else if (actionType == "decline")
                {
                    claim.ClaimStatus = "Declined by Academic Manager";
                }

                return RedirectToAction("ManageProcessedClaims");
            }
            catch (Exception ex)
            {
                // Log the exception
                _logger.LogError(ex, $"An error occurred while processing the claim with ID {claimId}.");
                ModelState.AddModelError("", "An unexpected error occurred while processing the claim. Please try again later.");
                return RedirectToAction("ManageProcessedClaims");
            }
        }
    }


}
