﻿using Microsoft.AspNetCore.Mvc;
using Prog6212PartTwo_ST10159832_KeenanGhisyan.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging; 
using System;
using System.Collections.Generic;
using System.Linq;


namespace Prog6212PartTwo_ST10159832_KeenanGhisyan.Controllers
{
   
    public class CoordinatorController : Controller
    {
        private readonly ILogger<CoordinatorController> _logger; // Declare the logger

        // Inject the logger through the constructor
        public CoordinatorController(ILogger<CoordinatorController> logger)
        {
            _logger = logger; // Initialize the logger
        }

        // GET: ProgrammeCoordinatorDetails
        public ActionResult ProgrammeCoordinatorDetails()
        {
            return View();
        }

        // POST: ProgrammeCoordinatorDetails
     
    }

}
