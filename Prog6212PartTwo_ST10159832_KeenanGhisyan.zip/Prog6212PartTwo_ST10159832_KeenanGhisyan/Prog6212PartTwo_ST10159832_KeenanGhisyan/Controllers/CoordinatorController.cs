﻿using Microsoft.AspNetCore.Mvc;
using Prog6212PartTwo_ST10159832_KeenanGhisyan.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging; 
using System;
using System.Collections.Generic;
using System.Linq;


namespace Prog6212PartTwo_ST10159832_KeenanGhisyan.Controllers
{

    public class CoordinatorController : Controller
    {
        private readonly ILogger<CoordinatorController> _logger; // Declare the logger

        // Inject the logger through the constructor
        public CoordinatorController(ILogger<CoordinatorController> logger)
        {
            _logger = logger; // Initialize the logger
        }

        // GET: ProgrammeCoordinatorDetails
        public ActionResult ProgrammeCoordinatorDetails()
        {
            return View();
        }

        // POST: ProgrammeCoordinatorDetails
        [HttpPost]
        public ActionResult ProgrammeCoordinatorDetails(CoordinatorClaimsViewModel model)
        {
            try
            {
                if (!string.IsNullOrEmpty(model.UserId) && model.UserId.StartsWith("1"))
                {
                    if (model.Password == "admin")
                    {
                        // ID and password are valid, redirect to claims page
                        return RedirectToAction("CoordinatorClaims", "Coordinator");
                    }
                    else
                    {
                        // Password is invalid, show error and retain form data except password
                        ModelState.AddModelError("Password", "The password is incorrect. Please try again.");
                    }
                }
                else
                {
                    // ID is invalid, clear the UserId field and show error message
                    model.UserId = string.Empty; // Clear UserId field
                    ModelState.AddModelError("UserId", "Invalid User ID. Please try again.");
                }

                // Return the view with the model and error messages
                return View(model);
            }
            catch (Exception ex)
            {
                // Log the exception
                _logger.LogError(ex, "An error occurred while processing the Programme Coordinator details.");
                ModelState.AddModelError("", "An unexpected error occurred. Please try again later.");
                return View(model);
            }
        }

        // GET: Display claims pending approval by the Programme Coordinator
        public ActionResult CoordinatorClaims()
        {
            try
            {
                // Fetch the claims pending approval by the Programme Coordinator
                var pendingClaims = LecturerController.ClaimsList
                    .Where(c => c.ClaimStatus == "Pending Coordinator Approval").ToList();

                // Pass the claims to the view
                var viewModel = new CoordinatorClaimsViewModel
                {
                    ClaimsPendingApproval = pendingClaims
                };

                return View(viewModel);
            }
            catch (Exception ex)
            {
                // Log the exception
                _logger.LogError(ex, "An error occurred while fetching claims pending approval.");
                ModelState.AddModelError("", "An unexpected error occurred while fetching claims. Please try again later.");
                return View(new CoordinatorClaimsViewModel()); // Return an empty model or handle it as needed
            }
        }

        // POST: Approve, Decline, or Review claims
        [HttpPost]
        public ActionResult ProcessClaim(int claimId, string actionType)
        {
            try
            {
                // Find the claim to be processed
                var claim = LecturerController.ClaimsList.FirstOrDefault(c => c.ClaimId == claimId);
                if (claim == null)
                {
                    return NotFound();
                }

                // Process the claim based on the actionType
                if (actionType == "approve")
                {
                    claim.ClaimStatus = "Pending Academic Manager Approval";
                }
                else if (actionType == "decline")
                {
                    claim.ClaimStatus = "Declined by Coordinator";
                }
                else if (actionType == "review")
                {
                    return RedirectToAction("ReviewClaim", new { claimId = claim.ClaimId });
                }

                return RedirectToAction("CoordinatorClaims");
            }
            catch (Exception ex)
            {
                // Log the exception
                _logger.LogError(ex, "An error occurred while processing the claim.");
                ModelState.AddModelError("", "An unexpected error occurred while processing the claim. Please try again later.");
                return RedirectToAction("CoordinatorClaims");
            }
        }

        public ActionResult ReviewClaim(int claimId)
        {
            try
            {
                // Find the claim
                var claim = LecturerController.ClaimsList.FirstOrDefault(c => c.ClaimId == claimId);
                if (claim == null)
                {
                    return NotFound();
                }

                // Pass the claim details to the view
                return View(claim);
            }
            catch (Exception ex)
            {
                // Log the exception
                _logger.LogError(ex, "An error occurred while reviewing the claim.");
                return NotFound(); // Optionally handle the error and return a user-friendly message
            }
        }
    }


}
