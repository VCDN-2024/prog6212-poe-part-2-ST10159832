﻿using System.ComponentModel.DataAnnotations;

namespace Prog6212PartTwo_ST10159832_KeenanGhisyan.Models
{
    public class ClaimViewModel
    {
        
    }

 
}
