﻿using System.ComponentModel.DataAnnotations;

namespace Prog6212PartTwo_ST10159832_KeenanGhisyan.Models
{
    public class ClaimViewModel
    {
        public int ClaimId { get; set; }

        [Required(ErrorMessage = "Lecturer ID is required.")]
        [RegularExpression(@"^\d{4}$", ErrorMessage = "Lecturer ID must be exactly 4 digits.")]
        public string LecturerId { get; set; }

        public string LecturerName { get; set; }
        public string LecturerEmail { get; set; }

        [Required(ErrorMessage = "Hours Worked is required.")]
        [Range(0.01, double.MaxValue, ErrorMessage = "Hours Worked must be a positive number.")]
        public double HoursWorked { get; set; }

        [Required(ErrorMessage = "Hourly Rate is required.")]
        [Range(0.01, double.MaxValue, ErrorMessage = "Hourly Rate must be a positive number.")]
        public double HourlyRate { get; set; }

        public string SupportingDocumentUrl { get; set; }
        public string ClaimStatus { get; set; }
        public string ProcessedBy { get; set; } // Name of who processed the claim
        public string ApproverRole { get; set; } // Role of who processed (Coordinator or Manager)

        [Required(ErrorMessage = "Total Amount is required.")]
        [Range(0.01, double.MaxValue, ErrorMessage = "Total Amount must be a positive number.")]
        public double TotalAmount { get; set; }

        public double PayableAmount { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
        public string ModuleCode { get; set; }

        public IFormFile SupportingDocument { get; set; }
        public List<UploadedFile> SupportingDocuments { get; set; }
    }

    public class UploadedFile
    {
        public string FileName { get; set; }  // The name of the file
        public byte[] FileContent { get; set; }  // The file content in bytes
        public string ContentType { get; set; }  // The MIME type of the file
    }


}
