﻿using KeenanGhisyan_ST10159832_Prog6212PartTwo.Controllers;
using KeenanGhisyan_ST10159832_Prog6212PartTwo.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Moq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KeenanGhisyan_ST10159832_Prog6212PartTwo.Test.Tests
{
    public class CoordinatorControllerTests
    {
        private readonly CoordinatorController _controller;
        private readonly Mock<ILogger<CoordinatorController>> _loggerMock;

        public CoordinatorControllerTests()
        {
            // Create a mock for ILogger
            _loggerMock = new Mock<ILogger<CoordinatorController>>();

            // Initialize the controller with the mock logger
            _controller = new CoordinatorController(_loggerMock.Object);
        }

        [Fact]
        public void ProgrammeCoordinatorDetails_InvalidPassword_ReturnsError()
        {
            // Arrange: Set up a view model with an invalid password
            var model = new CoordinatorClaimsViewModel
            {
                UserId = "123",
                Password = "wrongpassword"
            };

            // Act: Call the method and capture the result
            var result = _controller.ProgrammeCoordinatorDetails(model) as ViewResult;

            // Assert: Verify that the method returned the view and added a password error
            Assert.NotNull(result);  // Ensure we got a ViewResult
            Assert.True(_controller.ModelState.ContainsKey("Password"));  // Ensure there's an error for the password
        }

        [Fact]
        public void ProgrammeCoordinatorDetails_ValidCredentials_RedirectsToCoordinatorClaims()
        {
            // Arrange: Set up a view model with valid credentials
            var model = new CoordinatorClaimsViewModel
            {
                UserId = "123",
                Password = "admin"
            };

            // Act: Call the method and capture the result
            var result = _controller.ProgrammeCoordinatorDetails(model) as RedirectToActionResult;

            // Assert: Verify that the user is redirected to the correct action
            Assert.NotNull(result);  // Ensure we got a redirect result
            Assert.Equal("CoordinatorClaims", result.ActionName);  // Check the redirect action
        }
    }
}
