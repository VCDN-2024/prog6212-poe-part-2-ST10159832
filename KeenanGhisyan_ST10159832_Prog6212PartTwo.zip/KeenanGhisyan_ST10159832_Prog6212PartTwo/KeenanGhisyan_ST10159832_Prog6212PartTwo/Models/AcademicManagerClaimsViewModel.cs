﻿using System.ComponentModel.DataAnnotations;

namespace KeenanGhisyan_ST10159832_Prog6212PartTwo.Models
{
    public class AcademicManagerClaimsViewModel
    {
        [Required(ErrorMessage = "User ID is required.")]
        [RegularExpression(@"^\d{4}$", ErrorMessage = "User ID must be exactly 4 digits.")]
        public string UserId { get; set; }

        [Required(ErrorMessage = "Name is required.")]
        public string Name { get; set; }

        [Required(ErrorMessage = "Email is required.")]
        [EmailAddress(ErrorMessage = "Invalid Email Address.")]
        public string Email { get; set; }

        [Required(ErrorMessage = "Password is required.")]
        public string Password { get; set; }

        public List<ClaimViewModel> ProcessedClaims { get; set; }
    }
}
