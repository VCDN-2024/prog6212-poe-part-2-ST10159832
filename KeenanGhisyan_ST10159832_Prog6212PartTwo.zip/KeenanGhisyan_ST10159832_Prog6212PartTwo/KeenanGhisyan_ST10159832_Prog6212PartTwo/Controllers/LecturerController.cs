﻿using KeenanGhisyan_ST10159832_Prog6212PartTwo.Models;
using Microsoft.AspNetCore.Mvc;

namespace KeenanGhisyan_ST10159832_Prog6212PartTwo.Controllers
{
    public class LecturerController : Controller
    {
        // Static list to store lecturer details
        public static List<LecturerViewModel> LecturerList = new List<LecturerViewModel>();//https://www.youtube.com/watch?v=6bPeFO10GN4 

        // Static list to store claims
        public static List<ClaimViewModel> ClaimsList = new List<ClaimViewModel>();//https://www.youtube.com/watch?v=6bPeFO10GN4 
        // https://learn.microsoft.com/en-us/aspnet/mvc/overview/getting-started/getting-started-with-ef-using-mvc/updating-related-data-with-the-entity-framework-in-an-asp-net-mvc-application 
        public IActionResult LecturerDetails()
        {
            return View();
        }

        [HttpPost]
        public IActionResult SubmitLecturerDetails(string lecturerId, string lecturerName, string lecturerEmail)
        {
            // Add lecturer details to the static list
            LecturerList.Add(new LecturerViewModel
            {
                LecturerId = lecturerId,
                LecturerName = lecturerName,
                LecturerEmail = lecturerEmail
            });

            // Redirect to the next form for hours worked, hourly rate, etc.
            return RedirectToAction("LecturerInfo");
        }

        public IActionResult LecturerInfo()
        {
            return View();
        }

        [HttpPost]   //ASP.NET MVC - Passing Data From Controller To View
        public IActionResult SubmitWorkDetails(double hoursWorked, double hourlyRate, double totalAmount, DateTime startDate, DateTime endDate, string moduleCode, IFormFile supportingDocument)
        { //https://www.youtube.com/watch?v=1DYtHm2B1aA 
            try
            {
                DateTime currentDate = DateTime.Now;

                // Check if the startDate is in the future
                //https://www.youtube.com/watch?v=gOtZSaLPu-E 
                if (startDate > currentDate)
                {
                    ModelState.AddModelError("DateValidation", "The start date cannot be in the future. Please enter a valid start date.");
                }

                // Check if the endDate is in the future
                if (endDate > currentDate)//https://www.w3resource.com/csharp-exercises/exception-handling/csharp-exception-handling-exercise-9.php 
                {
                    ModelState.AddModelError("DateValidation", "The end date cannot be in the future. Please enter a valid end date.");
                }

                // Check if the endDate is more than 4 months from startDate
                if (endDate > startDate.AddMonths(4))
                {
                    ModelState.AddModelError("DateRange", "The end date cannot be more than 4 months apart from the start date. Please enter valid dates.");
                }

                // Validate hours worked
                if (hoursWorked < 0 || hoursWorked > 44)
                {
                    ModelState.AddModelError("HoursWorked", "Hours worked must be between 0 and 44. Please enter a valid number of hours.");
                }

                // Validate hourly rate
                if (hourlyRate <= 0 || hourlyRate > 1500)
                {
                    ModelState.AddModelError("HourlyRate", "Hourly rate must be greater than 0 and cannot exceed 1500. Please enter a valid rate.");
                }

                if (supportingDocument != null) // https://www.youtube.com/watch?v=T_kOi6J0040 
                {
                    // File size validation
                    const long maxFileSize = 6 * 1024 * 1024; // 6 MB in bytes
                    if (supportingDocument.Length > maxFileSize)
                    {
                        ModelState.AddModelError("SupportingDocument", "The file size must not exceed 6MB.");
                    }

                    // File type validation
                    var allowedExtensions = new[] { ".pdf", ".docx", ".xlsx" };
                    var fileExtension = Path.GetExtension(supportingDocument.FileName).ToLower();

                    if (!allowedExtensions.Contains(fileExtension))
                    {
                        ModelState.AddModelError("SupportingDocument", "Only PDF, DOCX, and XLSX files are allowed.");
                    }
                }

                // If there are validation errors, return the same view with error messages
                if (!ModelState.IsValid)
                {
                    return View("LecturerInfo", new ClaimViewModel
                    {
                        HoursWorked = hoursWorked,
                        HourlyRate = hourlyRate,
                        TotalAmount = totalAmount,
                        ModuleCode = moduleCode,
                        StartDate = startDate,
                        EndDate = endDate
                    });
                }

                // Calculate the payable amount
                double payableAmount = hoursWorked * hourlyRate;

                var newClaim = new ClaimViewModel
                {
                    ClaimId = ClaimsList.Count + 1,
                    LecturerId = LecturerList.Last().LecturerId,
                    LecturerName = LecturerList.Last().LecturerName,
                    HoursWorked = hoursWorked,
                    HourlyRate = hourlyRate,
                    TotalAmount = totalAmount,
                    PayableAmount = payableAmount,
                    ClaimStatus = "Pending Coordinator Approval", // Initial status
                    SupportingDocuments = new List<UploadedFile>(),
                    StartDate = startDate,
                    EndDate = endDate,
                    ModuleCode = moduleCode
                };

                // Handle the file upload and save to disk
                if (supportingDocument != null && supportingDocument.Length > 0)
                {
                    try
                    {
                        // Save the file to the wwwroot/uploads directory
                        var uploadsFolder = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", "uploads");
                        if (!Directory.Exists(uploadsFolder))
                        {
                            Directory.CreateDirectory(uploadsFolder);
                        }

                        // Construct the file path and save it
                        var filePath = Path.Combine(uploadsFolder, supportingDocument.FileName);
                        using (var stream = new FileStream(filePath, FileMode.Create))
                        {
                            supportingDocument.CopyTo(stream);
                        }

                        // Add the URL to SupportingDocuments
                        newClaim.SupportingDocuments.Add(new UploadedFile
                        {
                            FileName = supportingDocument.FileName,
                            FileContent = null, // No need to store content in memory, use file system instead
                            ContentType = supportingDocument.ContentType
                        });

                        // Store the URL for viewing later
                        newClaim.SupportingDocumentUrl = "/uploads/" + supportingDocument.FileName;
                    }
                    catch (Exception ex)
                    {
                        ModelState.AddModelError("", "Error while uploading the file. Please try again.");
                        // Optionally log the exception: e.g., Log.Error(ex);
                        return View("LecturerInfo");
                    }
                }

                // Add the claim to the list
                ClaimsList.Add(newClaim);

                // Redirect to home or another page after submission
                return RedirectToAction("LecturerClaims", "Lecturer");
            }
            catch (Exception ex)
            {
                ModelState.AddModelError("", "An error occurred while submitting your work details. Please try again.");
                // Optionally log the exception: e.g., Log.Error(ex);
                return View("LecturerInfo");
            }
        }


        public IActionResult LecturerClaims()
        {
            // Return the list of claims
            var claims = ClaimsList;
            return View(claims);
        }

        public IActionResult ViewClaim(int claimId)
        {
            // Fetch the claim details using claimId from the in-memory list
            var claim = ClaimsList.FirstOrDefault(c => c.ClaimId == claimId);

            if (claim == null)
            {
                return NotFound();
            }

            return View(claim);
        }

        [HttpPost]
        public IActionResult UploadDocument(int claimId, IFormFile file)
        {
            try
            {
                // Find the claim
                var claim = ClaimsList.FirstOrDefault(c => c.ClaimId == claimId);
                if (claim == null)
                {
                    return NotFound();
                }

                // Check if a file was uploaded
                if (file != null && file.Length > 0)
                {
                    using (var ms = new MemoryStream())
                    {
                        file.CopyTo(ms);
                        var fileBytes = ms.ToArray();

                        // Create an UploadedFile object and store it in the claim
                        var uploadedFile = new UploadedFile
                        {
                            FileName = file.FileName,
                            FileContent = fileBytes,
                            ContentType = file.ContentType
                        };

                        // Add the file to the claim's SupportingDocuments list
                        claim.SupportingDocuments.Add(uploadedFile);
                    }
                }

                return RedirectToAction("ViewClaim", new { claimId });
            }
            catch (Exception ex)
            {
                ModelState.AddModelError("", "An error occurred while uploading the document. Please try again.");
                // Optionally log the exception: e.g., Log.Error(ex);
                return View("Error");
            }
        }

        public IActionResult DownloadDocument(int claimId, string fileName)
        {
            try
            {
                // Find the claim
                var claim = ClaimsList.FirstOrDefault(c => c.ClaimId == claimId);
                if (claim == null || claim.SupportingDocuments == null)
                {
                    return NotFound();
                }

                // Construct the file path
                var filePath = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", "uploads", fileName);

                // Check if the file exists
                if (!System.IO.File.Exists(filePath))
                {
                    return NotFound();
                }

                // Get the content type of the file
                var contentType = "application/octet-stream";
                if (fileName.EndsWith(".pdf"))
                {
                    contentType = "application/pdf";
                }
                else if (fileName.EndsWith(".docx"))
                {
                    contentType = "application/vnd.openxmlformats-officedocument.wordprocessingml.document";
                }
                else if (fileName.EndsWith(".xlsx"))
                {
                    contentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
                }

                // Read the file and return it as a FileResult
                var fileBytes = System.IO.File.ReadAllBytes(filePath);
                return File(fileBytes, contentType, fileName);
            }
            catch (Exception ex)
            {
                ModelState.AddModelError("", "An error occurred while downloading the document. Please try again.");
                // Optionally log the exception: e.g., Log.Error(ex);
                return View("Error");
            }
        }

        [HttpPost]
        public IActionResult ApproveClaim(int claimId)//https://www.youtube.com/watch?v=3i0RcKrVyTo 
        {
            var claim = ClaimsList.FirstOrDefault(c => c.ClaimId == claimId);
            if (claim != null)
            {
                claim.ClaimStatus = "Approved";
            }
            return RedirectToAction("CoordinatorClaims");
        }

        [HttpPost]
        public IActionResult DeclineClaim(int claimId)
        {
            var claim = ClaimsList.FirstOrDefault(c => c.ClaimId == claimId);
            if (claim != null)
            {
                claim.ClaimStatus = "Declined";
            }
            return RedirectToAction("CoordinatorClaims");
        }

        [HttpPost]
        public IActionResult MarkAsReviewing(int claimId) //https://www.youtube.com/watch?v=T__S4GmQsYs 
        {
            var claim = ClaimsList.FirstOrDefault(c => c.ClaimId == claimId);
            if (claim != null)
            {
                claim.ClaimStatus = "Reviewing";
            }
            return RedirectToAction("CoordinatorClaims");
        }
    }
}
